module.exports = {
    dialect: "postgres",
    host: "172.25.0.2",
    username: "developer",
    password: "developer",
    database: "dev_database",
    define: {
        timestamps: false,
    },
};
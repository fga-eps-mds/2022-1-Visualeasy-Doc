import DisplayHome from "./components/DisplayHome"
const Home = () => {
  return (
    <DisplayHome/>
  )
}

export default Home
